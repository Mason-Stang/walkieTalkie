// Uncomment this line to run tests
//#define TESTING
#include <SPI.h>
#include <SD.h>
#include <Wire.h>
#include <TMRpcm.h>

void handleNewData();
void button_pushed();
void requestData();
void sendFile();
void requestEvent();
